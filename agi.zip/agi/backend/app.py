from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import requests
import base64
import io
import time
import json
import struct
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Hugging Face API Configuration
HF_API_URL = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0"
# Use environment variable for production, fallback for development
HF_TOKEN = os.getenv('HF_TOKEN')
```

**Just delete the part**: `, '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'`

---

## **File 2: backend/.env (CREATE NEW FILE)**

**Location**: Create a NEW file called `.env` in the `backend/` folder (same place as `app.py`)

**Put this inside:**
```
HF_TOKEN=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
```

---

## **File 3: .gitignore (CREATE OR EDIT)**

**Location**: In your project ROOT folder (where you see the `.git` folder)

**If the file doesn't exist, create it. Add these lines:**
```
.env
__pycache__/
*.pyc
venv/
node_modules/
HF_HEADERS = {"Authorization": f"Bearer {HF_TOKEN}"}

print("🚀 Starting AGI Generator Backend...")
print("📝 Make sure to add your Hugging Face token!")

def create_agi_file(image_bytes, prompt, model_name="stabilityai/stable-diffusion-xl-base-1.0"):
    """Create custom .agi file with embedded metadata"""
    
    # Create metadata
    metadata = {
        "format_version": "1.0",
        "generator": "AGI Generator",
        "timestamp": datetime.now().isoformat(),
        "prompt": prompt,
        "model": model_name,
        "warning": "AI Generated Content",
        "image_format": "PNG",
        "created_by": "Custom AGI Format v1.0"
    }
    
    # Convert metadata to JSON bytes
    metadata_json = json.dumps(metadata, indent=2)
    metadata_bytes = metadata_json.encode('utf-8')
    
    # Create .agi file structure
    agi_data = io.BytesIO()
    
    # Write file header: "AGI1" (4 bytes)
    agi_data.write(b"AGI1")
    
    # Write metadata size (4 bytes, little endian)
    agi_data.write(struct.pack('<I', len(metadata_bytes)))
    
    # Write metadata
    agi_data.write(metadata_bytes)
    
    # Write image data
    agi_data.write(image_bytes)
    
    return agi_data.getvalue()

def read_agi_file(agi_bytes):
    """Read and parse .agi file"""
    try:
        # Read header
        if agi_bytes[:4] != b"AGI1":
            return None, None
        
        # Read metadata size
        metadata_size = struct.unpack('<I', agi_bytes[4:8])[0]
        
        # Read metadata
        metadata_bytes = agi_bytes[8:8+metadata_size]
        metadata = json.loads(metadata_bytes.decode('utf-8'))
        
        # Read image data
        image_data = agi_bytes[8+metadata_size:]
        
        return metadata, image_data
    except:
        return None, None

@app.route('/')
def home():
    return jsonify({"message": "AGI Generator Backend is running!"})

@app.route('/test')
def test():
    return jsonify({"message": "AGI Generator API is running!"})

@app.route('/generate', methods=['POST'])
def generate_image():
    try:
        data = request.json
        prompt = data.get('prompt', '')
        
        if not prompt:
            return jsonify({"success": False, "error": "No prompt provided"}), 400
        
        print(f"Generating image for prompt: {prompt}")
        
        # Prepare payload for Hugging Face
        payload = {"inputs": prompt}
        
        # Make request to Hugging Face
        response = requests.post(HF_API_URL, headers=HF_HEADERS, json=payload, timeout=120)
        
        if response.status_code != 200:
            error_msg = f"Hugging Face API error: {response.status_code}"
            print(f"❌ {error_msg}")
            return jsonify({"success": False, "error": error_msg}), 500
        
        # Get image bytes
        image_bytes = response.content
        
        # Create .agi file
        agi_file_data = create_agi_file(image_bytes, prompt)
        
        # Convert to base64 for sending to frontend
        agi_base64 = base64.b64encode(agi_file_data).decode('utf-8')
        
        # Also create regular image preview for display
        image_base64 = base64.b64encode(image_bytes).decode('utf-8')
        image_data_url = f"data:image/png;base64,{image_base64}"
        
        print("✅ AGI file created successfully!")
        
        return jsonify({
            "success": True,
            "image_url": image_data_url,  # For preview
            "agi_data": agi_base64,       # For download
            "message": "AGI image generated successfully!"
        })
    
    except requests.exceptions.Timeout:
        error_msg = "Request timed out. The model might be loading, try again in a minute."
        print(f"⏰ {error_msg}")
        return jsonify({"success": False, "error": error_msg}), 408
    
    except Exception as e:
        error_msg = f"Unexpected error: {str(e)}"
        print(f"❌ {error_msg}")
        return jsonify({"success": False, "error": error_msg}), 500

@app.route('/view-agi', methods=['POST'])
def view_agi():
    """Endpoint to parse uploaded .agi files"""
    try:
        data = request.json
        agi_base64 = data.get('agi_data', '')
        
        if not agi_base64:
            return jsonify({"success": False, "error": "No AGI data provided"}), 400
        
        # Decode base64
        agi_bytes = base64.b64decode(agi_base64)
        
        # Parse .agi file
        metadata, image_data = read_agi_file(agi_bytes)
        
        if metadata is None:
            return jsonify({"success": False, "error": "Invalid AGI file format"}), 400
        
        # Convert image to base64 for display
        image_base64 = base64.b64encode(image_data).decode('utf-8')
        image_data_url = f"data:image/png;base64,{image_base64}"
        
        return jsonify({
            "success": True,
            "metadata": metadata,
            "image_url": image_data_url
        })
    
    except Exception as e:
        error_msg = f"Error reading AGI file: {str(e)}"
        return jsonify({"success": False, "error": error_msg}), 500

if __name__ == '__main__':
    # Get port from environment variable for deployment (Railway, Heroku, etc.)
    port = int(os.environ.get('PORT', 5000))
    # Use 0.0.0.0 to bind to all interfaces for deployment
    app.run(host='0.0.0.0', port=port, debug=False)